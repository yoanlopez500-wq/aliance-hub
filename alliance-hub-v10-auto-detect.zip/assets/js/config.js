// assets/js/config.js
// ⚠️ REEMPLAZA ESTOS VALORES con los de tu proyecto Supabase
const SUPABASE_URL = 'https://TU-PROJECT.supabase.co';
const SUPABASE_ANON_KEY = 'TU-ANON-KEY';

// El CDN de Supabase carga 'window.supabase' como namespace.
// Sobrescribimos window.supabase con el cliente creado para que sea global.
window.supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
