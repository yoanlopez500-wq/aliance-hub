// service-worker.js
const CACHE_NAME = 'alliance-hub-v1';

const urlsToCache = [
  './',
  './index.html',
  './login.html',
  './rankings.html',
  './game.html',
  './player.html',
  './admin/index.html',
  './admin/games.html',
  './admin/game-detail.html',
  './admin/alliances.html',
  './admin/players.html',
  './admin/import.html',
  './admin/invites.html',
  './register/index.html',
  './assets/js/config.js',
  './assets/js/auth.js',
  './assets/js/ui-utils.js',
  './assets/js/csv-parser.js',
  './assets/js/pwa-utils.js',
  './assets/css/style.css',
  './manifest.json'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Caching URLs...');
        return cache.addAll(urlsToCache);
      })
      .catch(err => console.log('Cache install error:', err))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  // IGNORAR completamente requests HEAD y no-GET
  if (event.request.method !== 'GET') {
    return;
  }

  // IGNORAR requests de analytics, tracking, extensiones, supabase
  const url = new URL(event.request.url);
  if (url.pathname.includes('chrome-extension') || 
      url.pathname.includes('extension') ||
      event.request.url.includes('supabase.co') ||
      event.request.url.includes('google-analytics')) {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then(response => {
        // Solo cachear respuestas válidas y GET
        if (response && response.status === 200 && event.request.method === 'GET') {
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, responseClone).catch(err => {
              // Ignorar errores de cache (ej: HEAD requests que se convierten)
              console.log('Cache put error (ignorado):', err);
            });
          });
        }
        return response;
      })
      .catch(() => {
        // Fallback a cache solo para GET
        if (event.request.method === 'GET') {
          return caches.match(event.request);
        }
        return new Response('Offline', { status: 503 });
      })
  );
});
