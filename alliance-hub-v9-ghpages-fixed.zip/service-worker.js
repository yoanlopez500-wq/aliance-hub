// service-worker.js
const CACHE_NAME = 'alliance-hub-v1';

// Rutas relativas al scope del SW (que está en /alliance-hub/)
const urlsToCache = [
  './',
  './index.html',
  './login.html',
  './rankings.html',
  './game.html',
  './player.html',
  './admin/index.html',
  './admin/games.html',
  './admin/game-detail.html',
  './admin/alliances.html',
  './admin/players.html',
  './admin/import.html',
  './admin/invites.html',
  './register/index.html',
  './assets/js/config.js',
  './assets/js/auth.js',
  './assets/js/ui-utils.js',
  './assets/js/csv-parser.js',
  './assets/js/pwa-utils.js',
  './assets/css/style.css',
  './manifest.json'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Caching URLs:', urlsToCache);
        return cache.addAll(urlsToCache);
      })
      .catch(err => console.log('Cache install error:', err))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  // Solo cachear GET requests
  if (event.request.method !== 'GET') return;

  event.respondWith(
    fetch(event.request)
      .then(response => {
        if (response && response.status === 200) {
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, responseClone);
          });
        }
        return response;
      })
      .catch(() => {
        return caches.match(event.request);
      })
  );
});
